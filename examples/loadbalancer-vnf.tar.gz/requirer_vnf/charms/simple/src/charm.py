#!/usr/bin/env python3
##
# Copyright 2020 Canonical Ltd.
# All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.
##

import sys

sys.path.append("lib")

from charms.osm.sshproxy import SSHProxyCharm
from ops.main import main
import time
import json

class MySSHProxyCharm(SSHProxyCharm):

    def __init__(self, framework, key):
        super().__init__(framework, key)

        # Listen to charm events
        self.framework.observe(self.on.config_changed, self.on_config_changed)
        self.framework.observe(self.on.install, self.on_install)
        self.framework.observe(self.on.start, self.on_start)

        # Listen to the touch action event
        self.framework.observe(self.on.touch_action, self.on_touch_action)
        self.framework.observe(self.on.ns_relate_init_action, self.on_ns_relate_init)
        self.framework.observe(self.on.ns_relate_join_action, self.on_ns_relate_join)
        self.framework.observe(self.on.install_haproxy_action, self.on_install_haproxy)

    def on_config_changed(self, event):
        """Handle changes in configuration"""
        super().on_config_changed(event)

    def on_install(self, event):
        """Called when the charm is being installed"""
        super().on_install(event)

    def on_start(self, event):
        """Called when the charm is being started"""
        super().on_start(event)
        
    def on_install_haproxy(self, event):
        proxy = self.get_ssh_proxy()
        stdout, stderr = proxy.run("sudo apt-get update")
        stdout, stderr = proxy.run("sudo apt-get install haproxy -y")
        event.set_results({"output": stdout})

    def on_touch_action(self, event):
        """Touch a file."""
        time.sleep(15)
        if self.model.unit.is_leader():
            filename = event.params["filename"]
            proxy = self.get_ssh_proxy()
            stdout, stderr = proxy.run("touch {}".format(filename))
            event.set_results({"output": stdout})
        else:
            event.fail("Unit is not leader")
            return
    
    def on_ns_relate_init(self, event):
        proxy = self.get_ssh_proxy()
        stdout, stderr = proxy.run("ec2metadata --public-ipv4")
        ip = stdout + ":8000"
        event.set_results({"output": json.dumps({"type": "requirer", "ip": ip})})
    
    def on_ns_relate_join(self, event):
        nsData = event.params["ns-data"]
        data = json.loads(nsData)
        providerIp = []
        for x in data:
            if (x['type'] == 'provider'):
                providerIp.append(x['ip'])
        self.configureHaProxy(providerIp)
        event.set_results({"output": providerIp})

    def configureHaProxy(self, serverList):
        proxy = self.get_ssh_proxy()
        haProxyCfg = self.getHaproxyConfig(serverList)
        filename = "/etc/haproxy/haproxy.cfg"
        self.write_text_to_file(proxy, haProxyCfg, filename)
        proxy.run("sudo systemctl restart haproxy")

    def getHaproxyConfig(self, serverList):
        text = """global
    log /dev/log local0 info # Enable logging
defaults
    mode http
    balance roundrobin # Round-robin load balancing
frontend app_frontend
    bind *:8000 # Listen on all interfaces on port 80
    default_backend app_backend
backend app_backend"""
        # sList = []
        i = 1
        for s in serverList:
           text += f"\n    server server{i} {s} check"
           i+=1
        return text
          
    def write_text_to_file(self, proxy, text, filename):
        # text = text.replace("\n", "\\n")
        tmpFilePath = "tmp.txt"
        f = open(tmpFilePath, "w")
        f.write(text)
        f.close()
        tmpDes = "/tmp/myTmpFile"
        proxy.scp(tmpFilePath, tmpDes)
        proxy.run("sudo mv {} {}".format(tmpDes, filename))

if __name__ == "__main__":
    main(MySSHProxyCharm)

